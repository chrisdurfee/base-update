/**
 * Connection
 * 
 * This will create a connection. 
 * @class 
 */
export class Connection
{
	/**
	 * This will be used to unsubscribe. 
	 */
	unsubscribe()
	{
		
	}
}