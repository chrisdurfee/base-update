import {base} from '../../core.js';

/**
 * This will remove a class and hide an element. 
 * 
 * @param {object} obj 
 * @param {string} animationClass 
 * @param {function} callBack 
 */
const removeClassAndHide = (obj, animationClass, callBack) =>
{  
	obj.style.display = 'none'; 
	removeAnimationClass(obj, animationClass, callBack); 
}; 

/**
 * This will remove a class when the animation is finished. 
 * 
 * @param {object} obj 
 * @param {string} animationClass 
 * @param {function} callBack 
 */
const removeAnimationClass = (obj, animationClass, callBack) =>
{ 
	if(typeof callBack === 'function') 
	{ 
		callBack.call(); 
	}
	
	base.removeClass(obj, animationClass); 
	animate.animating.remove(obj);   
};

const getElement = (element) =>
{ 
	return (typeof element === 'string')? document.getElementById(element) : element;
}; 

/* this will add and remove css animations */ 
export const animate = 
{ 
	/* this class tracks all objects being animated and can 
	add and remove them when completed */  
	animating: 
	{ 
		/**
		 * @param array objects
		 */
		objects: [],  
		
		/**
		 * This will add an animation. 
		 * 
		 * @param {object} object 
		 * @param {string} className 
		 * @param {int} timer 
		 */
		add(object, className, timer) 
		{ 
			if(!object) 
			{ 
				return; 
			}
			
			this.stopPreviousAnimations(object); 
			this.objects.push({ 
				object, 
				className, 
				timer 
			});  
		}, 
		
		/**
		 * This will remove an animation from an element. 
		 * 
		 * @param {object} object 
		 * @param {string} removeClass 
		 */
		remove(object, removeClass) 
		{ 
			if(!object) 
			{ 
				return; 
			}
					
			let animations = this.checkAnimating(object); 
			if(animations === false) 
			{ 
				return; 
			}

			let animation, indexNumber,
			objects = this.objects;
			for(var i = 0, maxLength = animations.length; i < maxLength; i++) 
			{ 
				animation = animations[i]; 
				/* we want to stop the timer */ 
				this.stopTimer(animation); 

				if(removeClass) 
				{ 
					/* we want to remove the className */ 
					base.removeClass(animation.object, animation.className); 
				}

				/* we want to remove the animation fron the object array */ 
				//var indexNumber = this.objects.indexOf(animation); 
				indexNumber = objects.indexOf(animation);
				if(indexNumber > -1) 
				{ 
					objects.splice(indexNumber, 1); 
				}
			} 
		}, 
		
		/**
		 * This will stop an animation timer.
		 * @param {object} animation 
		 */
		stopTimer(animation) 
		{ 
			if(animation) 
			{ 
				let timer = animation.timer; 
				window.clearTimeout(timer); 
			}
		}, 
		
		/**
		 * This will check if the element is animating.
		 * @param {object} obj 
		 * @return {(array|bool)}
		 */
		checkAnimating(obj) 
		{ 
			let animation, 
			animationArray = []; 
			
			/* we want to get any timers set for our object */ 
			let objects = this.objects; 
			for(var i = 0, maxLength = objects.length; i < maxLength; i++) 
			{ 
				animation = objects[i]; 
				if(animation.object === obj) 
				{ 
					animationArray.push(animation); 
				} 
			} 
			
			return (animationArray.length > 0)? animationArray : false;  
		}, 
		
		/**
		 * This will stop previous animations still animating.
		 * @param {object} obj 
		 */
		stopPreviousAnimations(obj) 
		{ 
			this.remove(obj, 1);   
		}, 
		
		/**
		 * This will reset the objects. 
		 */
		reset() 
		{ 
			this.objects = [];   
		}
	}, 
	
	/**
	 * This will create an animation. 
	 * 
	 * @param {object} obj 
	 * @param {string} animationClass 
	 * @param {int} duration 
	 * @param {function} callBack 
	 * @param {funtion} endCallBack 
	 */
	create(obj, animationClass, duration, callBack, endCallBack)
	{ 
		let animationCallBack = base.createCallBack(null, callBack, [obj, animationClass, endCallBack]);
		
		let timer = window.setTimeout(animationCallBack, duration); 
		this.animating.add(obj, animationClass, timer);
	}, 
	
	/**
	 * This will add an animation then hide the element. 
	 * 
	 * @param {object} object 
	 * @param {string} animationClass 
	 * @param {int} duration 
	 * @param {function} endCallBack 
	 */  
	hide(object, animationClass, duration, endCallBack)
	{ 
		let obj = getElement(object); 
		base.addClass(obj, animationClass);     
		
		this.create(obj, animationClass, duration, removeClassAndHide, endCallBack); 
	}, 
	
	/**
	 * This will add an animation then show the element. 
	 * 
	 * @param {object} object 
	 * @param {string} animationClass 
	 * @param {int} duration 
	 * @param {function} endCallBack 
	 */ 
	show(object, animationClass, duration, endCallBack)
	{ 
		let obj = getElement(object); 
		base.addClass(obj, animationClass); 
		obj.style.display = 'block'; 
		
		this.create(obj, animationClass, duration, removeAnimationClass, endCallBack);
	},  
	
	/**
	 * This will add an animation to the element. 
	 * 
	 * @param {object} object 
	 * @param {string} animationClass 
	 * @param {int} duration 
	 * @param {function} endCallBack 
	 */ 
	set(object, animationClass, duration, endCallBack)
	{ 
		let obj = getElement(object); 
		base.addClass(obj, animationClass);   
		
		this.create(obj, animationClass, duration, removeAnimationClass, endCallBack);
	} 
};